#include <iostream>
#include <string>
#include <sstream>
#include <curl/curl.h>
#include <json/json.h>

using namespace std;

size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

string fetchData(const string& url) {
    CURL* curl;
    CURLcode res;
    string readBuffer;

    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
        res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
    }
    return readBuffer;
}

void parseWeatherData(const string& data) {
    Json::Value jsonData;
    Json::CharReaderBuilder reader;
    string errs;

    istringstream stream(data);
    if (!Json::parseFromStream(reader, stream, &jsonData, &errs)) {
        cout << "Failed to parse the JSON data: " << errs << endl;
        return;
    }

    string city = jsonData["name"].asString();
    float temp = jsonData["main"]["temp"].asFloat();
    string weather = jsonData["weather"][0]["description"].asString();

    cout << "City: " << city << endl;
    cout << "Temperature: " << temp << " C" << endl;
    cout << "Weather: " << weather << endl;
}

int main() {
    string apiKey = "your Own API key from openweathermap.org";
    string city;
    cout << "Enter your city Name: ";
    getline(cin, city);
    string url = "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";
    string weatherData = fetchData(url);
    parseWeatherData(weatherData);

    return 0;
}
